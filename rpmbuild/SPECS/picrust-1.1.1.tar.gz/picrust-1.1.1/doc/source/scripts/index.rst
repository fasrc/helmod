.. _index_scripts:

PICRUSt Script Index
====================

Documentation for all PICRUSt scripts can be found here. This is a web version of the information that can be obtained for each script by calling the script with the ``-h`` parameter. 

.. toctree::
   :maxdepth: 1
   :glob:

   ./*
