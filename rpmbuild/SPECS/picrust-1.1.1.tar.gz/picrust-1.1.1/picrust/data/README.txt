This is the PICRUSt data folder.

By placing PICRUSt's precalculated files in this folder, you avoid the need to 
specify their location on the hard drive whenever you wish to run
predict_metagenomes.py

Please take a moment to download the PICRUSt data files into this folder.

You can find the files on the PICRUSt website: 

http://picrust.github.io/picrust/picrust_precalculated_files.html

 

 
