************
Introduction
************

The cookbook remains incomplete with many sections not yet written. Rather than wait until it is complete before presenting it we provide it as is.

What we hope is clear from the Cookbook is that PyCogent has extensive capabilities that cover for many areas of genomic biology including, but not limited to: comparative genomics, metagenomics and systems biology.

If you have particular need of an example falling in any of the sections, please create a new issue on our GitHub `issue tracker <https://github.com/pycogent/pycogent/issues>`_. Better yet, if you write one, please consider submitting a `pull request <https://help.github.com/articles/using-pull-requests>`_ to the `PyCogent git repository on GitHub <https://github.com/pycogent/pycogent>`_ and we'll include it in PyCogent!
