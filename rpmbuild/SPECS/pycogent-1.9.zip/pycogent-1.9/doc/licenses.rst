Licenses and disclaimer
=======================

.. toctree::
   :maxdepth: 1
   :hidden:
   
   COGENT_LICENSE

PyCogent is released under the GPL license, a copy of which is included in the distribution (see :ref:`cogent_license`). Licenses for other code sources are left in place.

This software is provided "as-is". There are no expressed or implied warranties of any kind, including, but not limited to, the warranties of merchantability and fitness for a given application. In no event shall the authors be liable for any direct, indirect, incidental, special, exemplary or consequential damages (including, but not limited to, loss of use, data or profits, or business interruption) however caused and on any theory of liability, whether in contract, strict liability or tort (including negligence or otherwise) arising in any way out of the use of this software, even if advised of the possibility of such damage.
